
-- --------------------------------------------------------

--
-- Table structure for table `board_demand`
--

CREATE TABLE `board_demand` (
  `demandID` int(50) NOT NULL,
  `adminID` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `board_demand`
--

INSERT INTO `board_demand` (`demandID`, `adminID`, `id`) VALUES
(1, 1, 1),
(2, 3, 2),
(3, 2, 3);
