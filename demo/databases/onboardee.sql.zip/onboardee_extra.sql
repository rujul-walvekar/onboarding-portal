
--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminID`);

--
-- Indexes for table `board_demand`
--
ALTER TABLE `board_demand`
  ADD PRIMARY KEY (`demandID`),
  ADD KEY `adminID` (`adminID`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `board_details`
--
ALTER TABLE `board_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emailID` (`emailID`),
  ADD UNIQUE KEY `emailID_2` (`emailID`),
  ADD KEY `adminID` (`adminID`);

--
-- Indexes for table `board_status`
--
ALTER TABLE `board_status`
  ADD KEY `adminID` (`adminID`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `board_demand`
--
ALTER TABLE `board_demand`
  MODIFY `demandID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `board_details`
--
ALTER TABLE `board_details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `board_demand`
--
ALTER TABLE `board_demand`
  ADD CONSTRAINT `board_demand_ibfk_1` FOREIGN KEY (`adminID`) REFERENCES `admin` (`adminID`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `board_demand_ibfk_2` FOREIGN KEY (`id`) REFERENCES `board_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `board_details`
--
ALTER TABLE `board_details`
  ADD CONSTRAINT `board_details_ibfk_1` FOREIGN KEY (`adminID`) REFERENCES `admin` (`adminID`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `board_status`
--
ALTER TABLE `board_status`
  ADD CONSTRAINT `board_status_ibfk_1` FOREIGN KEY (`adminID`) REFERENCES `admin` (`adminID`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `board_status_ibfk_2` FOREIGN KEY (`id`) REFERENCES `board_details` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
