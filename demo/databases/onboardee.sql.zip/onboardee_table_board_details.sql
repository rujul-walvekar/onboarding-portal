
-- --------------------------------------------------------

--
-- Table structure for table `board_details`
--

CREATE TABLE `board_details` (
  `Name` char(50) DEFAULT NULL,
  `age` int(3) DEFAULT NULL,
  `num` int(15) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `location` varchar(200) DEFAULT NULL,
  `cgpa` float DEFAULT NULL,
  `skills` varchar(500) DEFAULT NULL,
  `emailID` varchar(50) DEFAULT NULL,
  `id` int(10) NOT NULL,
  `adminID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `board_details`
--

INSERT INTO `board_details` (`Name`, `age`, `num`, `company`, `location`, `cgpa`, `skills`, `emailID`, `id`, `adminID`) VALUES
('Rujul Walvekar', 21, 2147483647, 'Accolite Digital', 'Mumbai', 8.62, 'C++,Angular,SpringBoot,Java', 'rujul.walvekar@accolitedigital.com', 1, 1),
('Rima Singh', 23, 2147483647, 'Accolite India', 'Hyderabad', 8.9, 'C++,Angular,SpringBoot,Java,PHP', 'rima.s@accolitedigital.com', 2, 3),
('Riddhi', 22, 2147483647, 'Morgan Stanley', 'Bangalore HQ', 9.02, 'C++,Angular,SpringBoot,Java,PHP', 'riddhi.mongodi@accolitedigital.com', 3, 2);
