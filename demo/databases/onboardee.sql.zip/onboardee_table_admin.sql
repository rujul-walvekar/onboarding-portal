
-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminID` int(50) NOT NULL,
  `a_name` varchar(100) DEFAULT NULL,
  `a_num` int(255) DEFAULT NULL,
  `a_email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminID`, `a_name`, `a_num`, `a_email`) VALUES
(1, 'Vinay', 2147483647, 'vinay@accolite.digital.com'),
(2, 'Soham', 2147483647, 'soham.b@accolitedigital.com'),
(3, 'Ayushi', 2147483647, 'ayushi.s@accolitedigital.com');
