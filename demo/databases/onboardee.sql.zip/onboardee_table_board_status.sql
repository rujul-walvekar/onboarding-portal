
-- --------------------------------------------------------

--
-- Table structure for table `board_status`
--

CREATE TABLE `board_status` (
  `b_status` varchar(50) DEFAULT NULL,
  `boarding_status` varchar(50) DEFAULT NULL,
  `adminID` int(11) DEFAULT NULL,
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `board_status`
--

INSERT INTO `board_status` (`b_status`, `boarding_status`, `adminID`, `id`) VALUES
('pass', 'approved', 1, 1),
('verification needed', 'complete', 2, 3),
('rejected', 'rejected', 3, 2);
